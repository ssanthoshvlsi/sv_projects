#!/bin/bash

echo 1 > /sys/bus/pci/rescan


